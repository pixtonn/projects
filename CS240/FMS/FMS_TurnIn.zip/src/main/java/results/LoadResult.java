package results;

public class LoadResult extends Result {

}

package results;

public class FillResult extends Result{
}

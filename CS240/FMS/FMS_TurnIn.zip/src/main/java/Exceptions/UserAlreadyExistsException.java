package Exceptions;

public class UserAlreadyExistsException extends Exception {
}

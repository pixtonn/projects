package Exceptions;

public class EventAlreadyExistsException extends Exception {
}

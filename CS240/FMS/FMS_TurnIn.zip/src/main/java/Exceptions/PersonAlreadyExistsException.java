package Exceptions;

public class PersonAlreadyExistsException extends Exception {
}

package Exceptions;

public class PersonNotFoundException extends Exception {
}

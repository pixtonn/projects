package Exceptions;

public class EventNotFoundException extends Exception {
}

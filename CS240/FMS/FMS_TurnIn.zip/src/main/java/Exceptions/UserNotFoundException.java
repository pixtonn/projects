package Exceptions;

public class UserNotFoundException extends Exception {
}

package Exceptions;

public class TokenAlreadyExistsException extends Exception {
}

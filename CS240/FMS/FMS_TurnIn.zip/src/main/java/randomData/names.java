package randomData;

import java.util.List;

public class names {
    public List<String> getData() {
        return data;
    }

    public void setData(List<String> data) {
        this.data = data;
    }

    List<String> data;

    public names(List<String> data) {
        this.data = data;
    }
}

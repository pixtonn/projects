package randomData;

import java.util.List;

public class locations {
    List<location> data;




    public locations(List<location> data) {
        this.data = data;
    }

    public List<location> getData() {
        return data;
    }

    public void setData(List<location> data) {
        this.data = data;
    }
}

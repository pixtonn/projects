package requests;
import randomData.ReadInLoad;

public class LoadRequest {
    public ReadInLoad getData() {
        return data;
    }

    public void setData(ReadInLoad data) {
        this.data = data;
    }

    private ReadInLoad data;
}

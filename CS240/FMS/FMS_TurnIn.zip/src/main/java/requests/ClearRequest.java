package requests;

public class ClearRequest {
}
